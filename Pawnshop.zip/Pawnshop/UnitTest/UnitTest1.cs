﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Data.SqlClient;

namespace UnitTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            using (SqlConnection Unit = new SqlConnection(@"Data Source=DESKTOP-1UG35LL;Initial Catalog=Pawnshop;Integrated Security=True"))
            {
                Unit.Open();
                SqlCommand cmd = Unit.CreateCommand();
                string Login = "eternitylove@mail.ru";
                string Password = "Hassliebe";
                cmd.CommandText = $"Insert into [User] (Login, Password) values ('{Login}', '{Password}')";
                cmd.ExecuteScalar();
            }
        }
       
    }
}
