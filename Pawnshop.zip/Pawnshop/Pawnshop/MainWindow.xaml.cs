﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Pawnshop
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public static bool TestResult = false;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (textBox.Text == "")
            {
                MessageBox.Show("Вы не ввели логин");
            }
            else
            {
                if (passwordBox.Password == "")
                {
                    MessageBox.Show("Вы не ввели пароль");
                }
                else
                {
                    if (TestAuthorization(passwordBox.Password, textBox.Text))
                    {
                        
                        var User = Connect.GetContext().User.Where(a => a.Login == textBox.Text).First();
                        if (User.Password == passwordBox.Password)
                        {
                            Window1 wnd = new Window1();
                            wnd.Show();
                            this.Visibility = Visibility.Collapsed;
                            MessageBox.Show("Вы авторизированы");
                        }
                        else
                        {
                            MessageBox.Show("Вы ввели неправильный логин или пароль");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Такого пользователя не существует");
                    }
                }
            }
        }

        private bool TestAuthorization(string password, string text)
        {
            throw new NotImplementedException();

           PawnshopEntities1 db = new PawnshopEntities1();
            if (Connect.GetContext().User.Any(a => a.Login == text) == true)
            {
                var User  = Connect.GetContext().User.Where(a => a.Login == text).First();
                if (User.Password == password)
                {
                    TestResult = true;
                }
                else
                {
                    TestResult = false;
                }
            }
            return TestResult;
        }
        public static bool Validation(String Password, String Login)
        {
            bool result = false;
            if (Password == "")
            {
                result = false;
            }
            else
            {
                if (Login == "")
                {
                    result = false;
                }
                else
                {
                    result = true;
                }
            }
            return result;
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
    }
   
}
    
