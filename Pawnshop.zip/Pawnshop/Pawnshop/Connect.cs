﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pawnshop
{
    class Connect
    {
        private static PawnshopEntities1 bd;

        public static PawnshopEntities1 GetContext()
        {
            if (bd == null)
            {
                bd = new PawnshopEntities1();
            }
            return bd;
        }

    }
}
