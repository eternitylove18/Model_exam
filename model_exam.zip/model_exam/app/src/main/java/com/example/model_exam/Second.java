package com.example.model_exam;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class Second extends AppCompatActivity {
Button button2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        button2 = findViewById(R.id.button2);
        // код для перехода на карты
        button2.setOnClickListener(v -> {
            Intent intent;
            intent = new Intent();
            intent.setAction(Intent.ACTION_VIEW);
            intent.setData(Uri.parse("geo:55.044026, 82.917393"));
            startActivity(intent);
        });

    }
    // валидация на заполнение полей ввода
    public abstract static class TextValidator implements TextWatcher {
        private final EditText editTextTextMultiLine;
        private final EditText editTextTextMultiLine2;
        private final EditText editTextTextMultiLine6;

        public TextValidator(EditText editTextTextMultiLine2, EditText editTextTextMultiLine,EditText editTextTextMultiLine6 ) {
            this.editTextTextMultiLine = editTextTextMultiLine;
            this.editTextTextMultiLine2 = editTextTextMultiLine2;
            this.editTextTextMultiLine6 = editTextTextMultiLine6;

        }

        public abstract void validate(EditText editTextTextMultiLine2, EditText editTextTextMultiLine, EditText editTextTextMultiLine6 ,String text);

        @Override
        final public void afterTextChanged(Editable s) {
            String text = editTextTextMultiLine.getText().toString();
            validate(editTextTextMultiLine, text);
            String text1 = editTextTextMultiLine2.getText().toString();
            validate(editTextTextMultiLine2, text1);
            String text2 = editTextTextMultiLine6.getText().toString();
            validate(editTextTextMultiLine6, text2);
        }

        protected abstract void validate(EditText editTextTextMultiLine, String text);

        @Override
        final public void beforeTextChanged(CharSequence s, int start, int count, int after) { /* Don't care */ }

        @Override
        final public void onTextChanged(CharSequence s, int start, int before, int count) { /* Don't care */ }
    }

}
